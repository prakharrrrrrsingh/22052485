import React, { useState, useEffect } from "react";
import {
  fetchLatestPosts,
  getRandomProfileImage,
  getRandomPostImage,
} from "../../assets/apiService";
import {
  Typography,
  Card,
  CardContent,
  CardMedia,
  CardHeader,
  Box,
  Avatar,
  Grid,
  Chip,
  CircularProgress,
  Divider,
} from "@mui/material";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import CommentIcon from "@mui/icons-material/Comment";
import NewReleasesIcon from "@mui/icons-material/NewReleases";

const Feed = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [images, setImages] = useState({});

  const loadPosts = async () => {
    try {
      const data = await fetchLatestPosts();

      // Generate or reuse images
      const newImages = { ...images };
      data.forEach((post) => {
        if (!newImages[`user_${post.userId}`]) {
          newImages[`user_${post.userId}`] = getRandomProfileImage();
        }
        if (!newImages[`post_${post.id}`]) {
          newImages[`post_${post.id}`] = getRandomPostImage();
        }
      });

      setImages(newImages);
      setPosts(data);
      setLoading(false);
    } catch (err) {
      setError("Failed to load feed. Please try again later.");
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPosts();

    // Real-time updates every 10 seconds
    const interval = setInterval(loadPosts, 10000);
    return () => clearInterval(interval);
  }, []);

  const getTimeAgo = (timestamp) => {
    const now = new Date();
    const postTime = new Date(timestamp);
    const diffInSeconds = Math.floor((now - postTime) / 1000);

    if (diffInSeconds < 60) {
      return `${diffInSeconds} seconds ago`;
    } else if (diffInSeconds < 3600) {
      return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    } else if (diffInSeconds < 86400) {
      return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    } else {
      return `${Math.floor(diffInSeconds / 86400)} days ago`;
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", my: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ textAlign: "center", my: 5 }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Box
        display="flex"
        alignItems="center"
        justifyContent="space-between"
        sx={{ mb: 3 }}
      >
        <Typography variant="h4" sx={{ fontWeight: "medium" }}>
          Latest Updates
        </Typography>
        <Chip
          icon={<AccessTimeIcon />}
          label="Real-time Feed"
          color="secondary"
        />
      </Box>

      <Typography variant="body1" sx={{ mb: 3 }}>
        Stay updated with the most recent posts from our community.
      </Typography>

      {posts.length === 0 ? (
        <Box sx={{ textAlign: "center", my: 5 }}>
          <Typography>No posts available in the feed.</Typography>
        </Box>
      ) : (
        <Grid container spacing={3}>
          {posts.map((post, index) => (
            <Grid item xs={12} key={post.id}>
              <Card
                sx={{
                  mb: 2,
                  transition: "transform 0.2s",
                  "&:hover": {
                    transform: "translateY(-5px)",
                    boxShadow: 3,
                  },
                  borderLeft: index === 0 ? "4px solid #f50057" : "none",
                }}
              >
                <CardHeader
                  avatar={
                    <Avatar
                      src={images[`user_${post.userId}`]}
                      alt={post.userName}
                    >
                      {post.userName ? post.userName.charAt(0) : "?"}
                    </Avatar>
                  }
                  title={post.userName}
                  subheader={
                    <Box
                      component="span"
                      sx={{ display: "flex", alignItems: "center" }}
                    >
                      <AccessTimeIcon
                        fontSize="small"
                        sx={{ mr: 0.5, fontSize: "1rem" }}
                      />
                      {getTimeAgo(post.timestamp)}
                    </Box>
                  }
                  action={
                    index === 0 && (
                      <Chip
                        icon={<NewReleasesIcon />}
                        label="New"
                        color="secondary"
                        size="small"
                        sx={{ mr: 1 }}
                      />
                    )
                  }
                />
                <CardMedia
                  component="img"
                  height="250"
                  image={images[`post_${post.id}`]}
                  alt={post.title}
                />
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    {post.title}
                  </Typography>
                  <Typography variant="body1" paragraph>
                    {post.content}
                  </Typography>
                  <Box display="flex" justifyContent="flex-end">
                    <Chip
                      icon={<CommentIcon />}
                      label={`${post.commentCount} Comments`}
                      variant="outlined"
                    />
                  </Box>
                </CardContent>
              </Card>
              {index < posts.length - 1 && <Divider sx={{ my: 2 }} />}
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
};

export default Feed;
