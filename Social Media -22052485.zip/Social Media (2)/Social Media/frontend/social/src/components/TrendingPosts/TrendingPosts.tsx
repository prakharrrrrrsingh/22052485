import React, { useState, useEffect } from "react";
import {
  fetchTrendingPosts,
  getRandomProfileImage,
  getRandomPostImage,
} from "../apiService";
import {
  Typography,
  Card,
  CardContent,
  CardMedia,
  CardHeader,
  Box,
  Avatar,
  Grid,
  Chip,
  CircularProgress,
  Paper,
} from "@mui/material";
import CommentIcon from "@mui/icons-material/Comment";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";

const TrendingPosts = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [images, setImages] = useState({});

  useEffect(() => {
    const getPosts = async () => {
      try {
        setLoading(true);
        const data = await fetchTrendingPosts();
        setPosts(data);

        // Generate random images for users and posts
        const newImages = {};
        data.forEach((post) => {
          newImages[`user_${post.userId}`] = getRandomProfileImage();
          newImages[`post_${post.id}`] = getRandomPostImage();
        });
        setImages(newImages);

        setLoading(false);
      } catch (err) {
        setError("Failed to load trending posts. Please try again later.");
        setLoading(false);
      }
    };

    getPosts();

    // Poll for updates every 30 seconds
    const interval = setInterval(getPosts, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", my: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ textAlign: "center", my: 5 }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Typography
        variant="h4"
        gutterBottom
        sx={{ mb: 3, fontWeight: "medium" }}
      >
        Trending Posts
      </Typography>

      <Box display="flex" alignItems="center" sx={{ mb: 3 }}>
        <TrendingUpIcon color="secondary" sx={{ mr: 1 }} />
        <Typography variant="body1">
          Posts with the highest engagement based on comment count.
        </Typography>
      </Box>

      {posts.length === 0 ? (
        <Paper sx={{ p: 3, textAlign: "center" }}>
          <Typography>No trending posts available right now.</Typography>
        </Paper>
      ) : (
        <Grid container spacing={3}>
          {posts.map((post) => (
            <Grid item xs={12} md={6} key={post.id}>
              <Card
                sx={{
                  height: "100%",
                  transition: "transform 0.2s",
                  "&:hover": {
                    transform: "translateY(-5px)",
                    boxShadow: 3,
                  },
                }}
              >
                <CardHeader
                  avatar={
                    <Avatar
                      src={images[`user_${post.userId}`]}
                      alt={post.userName}
                    >
                      {post.userName ? post.userName.charAt(0) : "?"}
                    </Avatar>
                  }
                  title={post.userName}
                  subheader={new Date(post.timestamp).toLocaleDateString()}
                />
                <CardMedia
                  component="img"
                  height="200"
                  image={images[`post_${post.id}`]}
                  alt={post.title}
                />
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    {post.title}
                  </Typography>
                  <Typography
                    variant="body2"
                    color="text.secondary"
                    sx={{ mb: 2 }}
                  >
                    {post.content}
                  </Typography>
                  <Box
                    display="flex"
                    justifyContent="space-between"
                    alignItems="center"
                  >
                    <Chip
                      icon={<CommentIcon />}
                      label={`${post.commentCount} Comments`}
                      color="secondary"
                    />
                    <Chip
                      icon={<TrendingUpIcon />}
                      label="Trending"
                      color="primary"
                    />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
};

export default TrendingPosts;
