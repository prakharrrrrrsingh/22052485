import React, { useState, useEffect } from "react";
import { fetchTopUsers, getRandomProfileImage } from "../apiService";
import {
  Typography,
  Card,
  CardContent,
  Box,
  Avatar,
  Grid,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Divider,
  Chip,
  CircularProgress,
} from "@mui/material";
import PersonIcon from "@mui/icons-material/Person";
import PostIcon from "@mui/icons-material/Article";

const TopUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [profileImages, setProfileImages] = useState({});

  useEffect(() => {
    const getUsers = async () => {
      try {
        setLoading(true);
        const data = await fetchTopUsers();
        setUsers(data);

        // Generate random profile images for each user
        const images = {};
        data.forEach((user) => {
          images[user.id] = getRandomProfileImage();
        });
        setProfileImages(images);

        setLoading(false);
      } catch (err) {
        setError("Failed to load top users. Please try again later.");
        setLoading(false);
      }
    };

    getUsers();

    // Poll for updates every 30 seconds
    const interval = setInterval(getUsers, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", my: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ textAlign: "center", my: 5 }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Typography
        variant="h4"
        gutterBottom
        sx={{ mb: 3, fontWeight: "medium" }}
      >
        Top Users
      </Typography>
      <Typography variant="body1" sx={{ mb: 3 }}>
        These users have created the most content on the platform.
      </Typography>

      <Grid container spacing={3}>
        {users.map((user, index) => (
          <Grid item xs={12} sm={6} md={4} key={user.id}>
            <Card
              sx={{
                height: "100%",
                display: "flex",
                flexDirection: "column",
                transition: "transform 0.2s",
                "&:hover": {
                  transform: "translateY(-5px)",
                  boxShadow: 3,
                },
              }}
            >
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                  <ListItemAvatar>
                    <Avatar
                      src={profileImages[user.id]}
                      alt={user.name}
                      sx={{
                        width: 60,
                        height: 60,
                        bgcolor:
                          index === 0 ? "secondary.main" : "primary.main",
                      }}
                    >
                      <PersonIcon />
                    </Avatar>
                  </ListItemAvatar>
                  <Box sx={{ ml: 2 }}>
                    <Typography variant="h6" component="div">
                      {user.name}
                    </Typography>
                    <Chip
                      icon={<PostIcon />}
                      label={`${user.postCount} Posts`}
                      color={index === 0 ? "secondary" : "primary"}
                      size="small"
                      sx={{ mt: 1 }}
                    />
                  </Box>
                </Box>
                <Divider sx={{ my: 2 }} />
                <Typography variant="body2" color="text.secondary">
                  {user.email || "No email available"}
                </Typography>
                {index === 0 && (
                  <Box
                    sx={{ mt: 2, display: "flex", justifyContent: "center" }}
                  >
                    <Chip label="Top Contributor" color="secondary" />
                  </Box>
                )}
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default TopUsers;
