import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import TopUsers from "./components/TopUsers/TopUsers";
import TrendingPosts from "./components/TrendingPosts/TrendingPosts";
import Feed from "./components/Feed/Feed";
import {
  AppBar,
  Toolbar,
  Typography,
  Container,
  Box,
  Paper,
  Tabs,
  Tab,
} from "@mui/material";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import DashboardIcon from "@mui/icons-material/Dashboard";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import FeedIcon from "@mui/icons-material/Feed";

const theme = createTheme({
  palette: {
    primary: {
      main: "#3f51b5",
    },
    secondary: {
      main: "#f50057",
    },
    background: {
      default: "#f5f5f5",
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
    },
  },
});

function App() {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Box sx={{ flexGrow: 1 }}>
          <AppBar position="static" color="primary">
            <Toolbar>
              <Typography variant="h5" component="div" sx={{ flexGrow: 1 }}>
                Social Media Analytics
              </Typography>
            </Toolbar>
            <Paper square>
              <Tabs
                value={value}
                onChange={handleChange}
                variant="fullWidth"
                indicatorColor="secondary"
                textColor="inherit"
                aria-label="navigation tabs"
              >
                <Tab
                  icon={<DashboardIcon />}
                  label="TOP USERS"
                  component={Link}
                  to="/"
                />
                <Tab
                  icon={<TrendingUpIcon />}
                  label="TRENDING POSTS"
                  component={Link}
                  to="/trending"
                />
                <Tab
                  icon={<FeedIcon />}
                  label="FEED"
                  component={Link}
                  to="/feed"
                />
              </Tabs>
            </Paper>
          </AppBar>
        </Box>

        <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
          <Routes>
            <Route path="/" element={<TopUsers />} />
            <Route path="/trending" element={<TrendingPosts />} />
            <Route path="/feed" element={<Feed />} />
          </Routes>
        </Container>
      </Router>
    </ThemeProvider>
  );
}

export default App;
