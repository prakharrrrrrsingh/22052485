import axios from "axios";

const API_URL = "http://localhost:3000";

export const fetchTopUsers = async () => {
  try {
    const response = await axios.get(`${API_URL}/users`);
    return response.data;
  } catch (error) {
    console.error("Error fetching top users:", error);
    throw error;
  }
};

export const fetchTrendingPosts = async () => {
  try {
    const response = await axios.get(`${API_URL}/posts?type=popular`);
    return response.data;
  } catch (error) {
    console.error("Error fetching trending posts:", error);
    throw error;
  }
};

export const fetchLatestPosts = async () => {
  try {
    const response = await axios.get(`${API_URL}/posts?type=latest`);
    return response.data;
  } catch (error) {
    console.error("Error fetching latest posts:", error);
    throw error;
  }
};

export const getRandomProfileImage = () => {
  const imageIds = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"];
  const randomId = imageIds[Math.floor(Math.random() * imageIds.length)];
  return `/api/placeholder/40/40`;
};

export const getRandomPostImage = () => {
  const sizes = [
    { width: 600, height: 400 },
    { width: 600, height: 300 },
    { width: 500, height: 500 },
  ];
  const randomSize = sizes[Math.floor(Math.random() * sizes.length)];
  return `/api/placeholder/${randomSize.width}/${randomSize.height}`;
};
