const express = require("express");
const axios = require("axios");
const NodeCache = require("node-cache");

const app = express();
const PORT = process.env.PORT || 3000;

const cache = new NodeCache({
  stdTTL: 60,
  checkperiod: 120,
});

const BASE_URL = "http://20.244.56.144/evaluation-service";

const AUTH_DETAILS = {
  "email": "22052485@kiit.ac.in",
  "name": "prakhar singh",
  "rollNo": "22052485",
  "accessCode": "nwpwrZ",
  "clientID": "a0412d77-f130-4f3a-8f22-4672bfb66b54",
  "clientSecret": "wepurRKCVvDHASEH"
};

let authToken = null;
let tokenExpiry = null;

app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

let userPostsMap = new Map();
let postsCommentsMap = new Map();
let latestPosts = [];

async function getAuthToken() {
  try {
    const now = Date.now() / 1000;
    if (authToken && tokenExpiry && tokenExpiry > now + 60) {
      return authToken;
    }

    console.log("Getting new authentication token...");

    const response = await axios.post(`${BASE_URL}/auth`, AUTH_DETAILS);

    if (response.data && response.data.access_token) {
      authToken = response.data.access_token;
      tokenExpiry = response.data.expires_in;
      console.log("Authentication token obtained successfully");
      return authToken;
    } else {
      throw new Error("Invalid authentication response");
    }
  } catch (error) {
    console.error("Authentication error:", error.message);
    throw error;
  }
}

async function fetchUsers() {
  try {
    const cacheKey = "all_users";
    const cachedUsers = cache.get(cacheKey);

    if (cachedUsers) {
      return cachedUsers;
    }

    const token = await getAuthToken();
    const response = await axios.get(`${BASE_URL}/users`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    const users = response.data;

    cache.set(cacheKey, users);

    return users;
  } catch (error) {
    console.error("Error fetching users:", error.message);
    throw error;
  }
}

async function fetchUserPosts(userId) {
  try {
    const cacheKey = `user_posts_${userId}`;
    const cachedPosts = cache.get(cacheKey);

    if (cachedPosts) {
      return cachedPosts;
    }

    const token = await getAuthToken();
    const response = await axios.get(`${BASE_URL}/users/${userId}/posts`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    const posts = response.data;

    cache.set(cacheKey, posts);

    return posts;
  } catch (error) {
    console.error(`Error fetching posts for user ${userId}:`, error.message);
    throw error;
  }
}

async function fetchPostComments(postId) {
  try {
    const cacheKey = `post_comments_${postId}`;
    const cachedComments = cache.get(cacheKey);

    if (cachedComments) {
      return cachedComments;
    }

    const token = await getAuthToken();
    const response = await axios.get(`${BASE_URL}/posts/${postId}/comments`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    const comments = response.data;

    cache.set(cacheKey, comments);

    return comments;
  } catch (error) {
    console.error(`Error fetching comments for post ${postId}:`, error.message);
    throw error;
  }
}

async function updateAnalyticsData() {
  try {
    console.log("Updating analytics data...");

    userPostsMap = new Map();
    postsCommentsMap = new Map();
    latestPosts = [];

    const users = await fetchUsers();

    for (const user of users) {
      const posts = await fetchUserPosts(user.id);

      userPostsMap.set(user.id, posts.length);

      for (const post of posts) {
        const comments = await fetchPostComments(post.id);
        postsCommentsMap.set(post.id, comments.length);

        latestPosts.push({
          id: post.id,
          userId: user.id,
          userName: user.name,
          title: post.title,
          content: post.content,
          timestamp: post.timestamp,
          commentCount: comments.length,
        });
      }
    }

    latestPosts.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    console.log("Analytics data updated successfully");

    cache.set("last_update_time", new Date().toISOString());
  } catch (error) {
    console.error("Error updating analytics data:", error.message);
    throw error;
  }
}

updateAnalyticsData()
  .then(() => console.log("Initial data load complete"))
  .catch((err) => console.error("Initial data load failed:", err.message));

setInterval(() => {
  updateAnalyticsData()
    .then(() => console.log("Scheduled update complete"))
    .catch((err) => console.error("Scheduled update failed:", err.message));
}, 5 * 60 * 1000);

app.get("/users", async (req, res) => {
  try {
    const lastUpdateTime = cache.get("last_update_time");
    if (!lastUpdateTime) {
      await updateAnalyticsData();
    }

    const userPostCounts = Array.from(userPostsMap, ([userId, postCount]) => ({
      userId,
      postCount,
    }));

    const topUsers = userPostCounts
      .sort((a, b) => b.postCount - a.postCount)
      .slice(0, 5);

    const users = await fetchUsers();
    const topUsersWithDetails = topUsers.map((topUser) => {
      const userDetails = users.find((user) => user.id === topUser.userId);
      return {
        ...userDetails,
        postCount: topUser.postCount,
      };
    });

    res.json(topUsersWithDetails);
  } catch (error) {
    console.error("Error in /users endpoint:", error.message);
    res.status(500).json({ error: "Failed to retrieve top users" });
  }
});

app.get("/posts", async (req, res) => {
  try {
    const type = req.query.type || "latest";

    const lastUpdateTime = cache.get("last_update_time");
    if (!lastUpdateTime) {
      await updateAnalyticsData();
    }

    if (type === "popular") {
      const maxCommentCount = Math.max(...postsCommentsMap.values());

      const popularPosts = latestPosts.filter(
        (post) => post.commentCount === maxCommentCount
      );

      res.json(popularPosts);
    } else if (type === "latest") {
      res.json(latestPosts.slice(0, 5));
    } else {
      res
        .status(400)
        .json({ error: 'Invalid type parameter. Use "popular" or "latest".' });
    }
  } catch (error) {
    console.error("Error in /posts endpoint:", error.message);
    res.status(500).json({ error: "Failed to retrieve posts" });
  }
});

app.get("/health", (req, res) => {
  const lastUpdateTime = cache.get("last_update_time") || "Not yet updated";
  res.json({
    status: "ok",
    lastDataUpdate: lastUpdateTime,
    cacheStats: cache.getStats(),
    authentication: {
      hasToken: !!authToken,
      expiresIn: tokenExpiry
        ? new Date(tokenExpiry * 1000).toISOString()
        : "Unknown",
    },
  });
});

app.post("/refresh", async (req, res) => {
  try {
    authToken = null;
    tokenExpiry = null;

    cache.flushAll();

    await updateAnalyticsData();
    res.json({ status: "ok", message: "Data refreshed successfully" });
  } catch (error) {
    res.status(500).json({ error: "Failed to refresh data" });
  }
});

app.listen(PORT, () => {
  console.log(`Social Media Analytics Microservice running on port ${PORT}`);
});

module.exports = app;
